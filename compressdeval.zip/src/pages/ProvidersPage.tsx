import React, { useState, useEffect } from 'react';
import { ArrowRight, X, Phone } from 'lucide-react';
import { Link } from 'react-router-dom';
import { doc, getDoc, onSnapshot } from 'firebase/firestore';
import { getDb } from '../lib/firebase';
import SeoHead from '../components/SeoHead';
import { NEWARK_PRACTICE_INFO } from '../data/localSeoData';
import { useCmsData } from '../context/CmsContext';

interface ProviderProfile {
  id: string;
  slug: string;
  name: string;
  role: string;
  image: string;
  specialties: string[];
  education: string;
  certifications: string[];
  languages: string[];
  bio: string;
  experience: string;
}

export default function ProvidersPage() {
  const { getMediaUrl, getSiteMedia } = useCmsData();
  const [selectedProvider, setSelectedProvider] = useState<ProviderProfile | null>(null);
  const [prahladPhoto, setPrahladPhoto] = useState<string>(
    'https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&q=85&w=1200'
  );

  useEffect(() => {
    try {
      const db = getDb();
      if (!db) return;
      const unsub = onSnapshot(doc(db, 'providers', 'dr-prahlad-gadhvi'), (snap) => {
        if (snap.exists() && snap.data()?.imageUrl) {
          setPrahladPhoto(snap.data().imageUrl);
        }
      });
      return () => unsub();
    } catch (err) {
      console.warn('Providers realtime listen err:', err);
    }
  }, []);

  const providers: ProviderProfile[] = [
    {
      id: 'dr-prahlad-gadhvi',
      slug: 'dr-prahlad-gadhvi',
      name: 'Dr. Prahlad Gadhvi',
      role: 'Primary Care Physician & Internist',
      image: prahladPhoto,
      specialties: ['Internal Medicine', 'Preventative Screenings', 'Chronic Illness Management', 'Geriatric Care'],
      education: 'MBBS, MD in Internal Medicine - Leading Medical Institutions',
      certifications: ['Board-Certified in Internal Medicine', 'American College of Physicians (ACP)', 'New Jersey State Medical License'],
      languages: ['English', 'Spanish', 'Hindi', 'Gujarati'],
      experience: '20+ Years in Newark & Northern NJ',
      bio: 'Dr. Prahlad Gadhvi has dedicated over two decades to primary care medicine in Newark. Known for his unhurried consultations and attentive bedside manner, Dr. Gadhvi treats the whole person rather than just isolating symptoms. He emphasizes proactive risk assessment, comprehensive lifestyle guidance, and personalized diagnostic workups.'
    },
    {
      id: 'dr-deval-gadhvi',
      slug: 'dr-deval-gadhvi',
      name: 'Dr. Deval Gadhvi',
      role: 'Medical Director & Primary Care Physician',
      image: 'https://images.unsplash.com/photo-1594824813627-2c9ffea824f9?auto=format&fit=crop&q=85&w=1200',
      specialties: ['Internal Medicine', "Women's Health", 'Preventative Cardiology', 'Metabolic Wellness'],
      education: 'MD - Internal Medicine Residency & Fellowships',
      certifications: ['ABIM Board-Certified', 'American Medical Association Member', 'New Jersey Board of Medical Examiners'],
      languages: ['English', 'Spanish', 'Hindi', 'Gujarati'],
      experience: '18+ Years Clinical Practice',
      bio: 'Dr. Deval Gadhvi serves as Medical Director at Newark Medical Associates. Her clinical focus encompasses comprehensive adult preventive medicine, womens wellness evaluations, hormonal health, and longitudinal management of hypertension and diabetes. She is deeply passionate about empowering patients with health literacy and collaborative wellness plans.'
    },
    {
      id: 'dr-sankalp-pathak',
      slug: 'dr-sankalp-pathak',
      name: 'Dr. Sankalp Pathak',
      role: 'Consulting Cardiologist & Diagnostics',
      image: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?auto=format&fit=crop&q=85&w=1200',
      specialties: ['Cardiology', 'Cardiac Ultrasound / ECHO', 'EKG Interpretation', 'Cardiovascular Risk Stratification'],
      education: 'MD, Cardiology Fellowship & Advanced Diagnostic Imaging',
      certifications: ['Board-Certified in Cardiovascular Disease', 'FACC Fellow of American College of Cardiology'],
      languages: ['English', 'Spanish', 'Hindi'],
      experience: '15+ Years Specialized Practice',
      bio: 'Dr. Sankalp Pathak brings extensive specialized expertise in non-invasive cardiovascular evaluations, in-office echocardiograms, stress testing interpretations, and pre-operative cardiac clearances. He works closely with our primary care internists to ensure seamless cardiopulmonary health management.'
    }
  ];

  return (
    <div className="bg-[#FCFBF8] text-[#252A2B] overflow-hidden">
      <SeoHead
        title="Our Physicians & Providers | Newark Medical Associates | Newark NJ"
        description="Meet board-certified primary care physicians Dr. Prahlad Gadhvi, Dr. Deval Gadhvi, and clinical team at Newark Medical Associates in Newark, NJ. Accepting new patients."
        keywords={[
          'Dr. Prahlad Gadhvi',
          'Dr. Deval Gadhvi',
          'primary care doctor Newark NJ',
          'internal medicine physician Newark',
          'doctors accepting new patients Newark'
        ]}
        canonicalUrl="https://newarkmed.com/providers"
      />

      {/* 1. Header Hero: Warm Ivory Editorial Hero */}
      <section className="bg-[#F4EFE6] py-20 sm:py-24 lg:py-28 border-b border-[#D9D0C5]">
        <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-12">
          <div className="max-w-4xl">
            <p className="text-[12px] uppercase font-bold tracking-[0.24em] text-[#B39A68] mb-4">
              Our Medical Team
            </p>
            <h1 className="font-serif text-[44px] sm:text-[58px] lg:text-[68px] text-[#0B1F2A] leading-[1.04] tracking-[-0.02em] mb-6">
              Meet the People<br />
              <span className="italic font-normal">Behind Your Care.</span>
            </h1>
            <p className="font-sans text-[18px] sm:text-[20px] text-[#5A6264] leading-[1.7] max-w-2xl">
              Board-certified internists who bring rigorous clinical training, decades of community dedication, and genuine empathy to every patient consultation.
            </p>
          </div>
        </div>
      </section>

      {/* 2. Editorial Provider Gallery (Large 4:5 Portrait Photography, NO white cards or borders) */}
      <section className="py-24 sm:py-28 lg:py-32 border-b border-[#D9D0C5]">
        <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-12">
          
          <div className="space-y-20 lg:space-y-24">
            {providers.map((docItem, index) => {
              const isEven = index % 2 === 0;
              return (
                <div
                  key={docItem.id}
                  className={`grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start pb-20 border-b border-[#D9D0C5] last:border-b-0 ${
                    isEven ? '' : 'lg:flex-row-reverse'
                  }`}
                >
                  {/* Portrait Column: 4:5 Ratio */}
                  <div className={`lg:col-span-5 ${isEven ? 'lg:order-1' : 'lg:order-2'}`}>
                    {(() => {
                      const dynPhoto = getMediaUrl('providers', 'doctors', docItem.id) ||
                        getMediaUrl('providers', 'doctors', docItem.id.replace('dr-', '')) ||
                        getMediaUrl('providers', docItem.slug, 'portrait') ||
                        getMediaUrl('providers', docItem.id, 'portrait') ||
                        getMediaUrl('providers', docItem.id.replace('dr-', ''), 'portrait') ||
                        docItem.image;
                      const dynMedia = getSiteMedia('providers', 'doctors', docItem.id) ||
                        getSiteMedia('providers', 'doctors', docItem.id.replace('dr-', '')) ||
                        getSiteMedia('providers', docItem.slug, 'portrait') ||
                        getSiteMedia('providers', docItem.id, 'portrait') ||
                        getSiteMedia('providers', docItem.id.replace('dr-', ''), 'portrait');
                      return (
                        <div className="relative aspect-[4/5] overflow-hidden bg-[#F4EFE6] border border-[#D9D0C5] shadow-editorial group">
                          <img
                            src={dynPhoto}
                            alt={dynMedia?.altText || docItem.name}
                            className="w-full h-full group-hover:scale-103 transition-transform duration-700"
                            style={{
                              objectFit: (dynMedia?.objectFit as any) || 'cover',
                              objectPosition: dynMedia?.position || 'center 20%'
                            }}
                            loading="lazy"
                            referrerPolicy="no-referrer"
                          />
                          <div className="absolute bottom-4 left-4 right-4 bg-[#0B1F2A]/90 p-3 text-center text-xs text-[#D9D0C5] uppercase tracking-widest font-semibold">
                            {docItem.experience}
                          </div>
                        </div>
                      );
                    })()}
                  </div>

                  {/* Biography & Details Column */}
                  <div className={`lg:col-span-7 ${isEven ? 'lg:order-2' : 'lg:order-1'} flex flex-col justify-between`}>
                    <div>
                      <p className="text-[12.5px] uppercase font-bold tracking-[0.2em] text-[#B39A68] mb-2">
                        {docItem.role}
                      </p>

                      <h2 className="font-serif text-[38px] sm:text-[46px] text-[#0B1F2A] leading-tight mb-4">
                        {docItem.name}
                      </h2>

                      <p className="font-sans text-[17px] text-[#5A6264] leading-[1.75] mb-8">
                        {docItem.bio}
                      </p>

                      {/* Clinical Specialties */}
                      <div className="mb-8">
                        <h4 className="font-serif text-[20px] text-[#0B1F2A] mb-3">
                          Clinical Specialties & Focus
                        </h4>
                        <div className="flex flex-wrap gap-2.5">
                          {docItem.specialties.map((spec, i) => (
                            <span
                              key={i}
                              className="px-3.5 py-1.5 bg-[#F4EFE6] text-[#0B1F2A] text-[13.5px] font-medium border border-[#D9D0C5]"
                            >
                              {spec}
                            </span>
                          ))}
                        </div>
                      </div>

                      {/* Languages Spoken */}
                      <div className="pt-4 border-t border-[#D9D0C5]/70 flex items-center gap-2 text-[14.5px] text-[#5A6264] mb-8">
                        <span className="font-semibold text-[#0B1F2A]">Languages:</span>
                        <span>{docItem.languages.join(', ')}</span>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-4">
                      <Link
                        to="/appointments"
                        className="inline-flex items-center justify-center px-7 py-3.5 bg-[#0B1F2A] hover:bg-[#153444] text-[#FCFBF8] text-[14px] font-bold uppercase tracking-wider transition-colors shadow-sm"
                      >
                        Schedule with {docItem.name.split(' ')[1] || 'Doctor'}
                      </Link>

                      <Link
                        to={`/providers/${docItem.slug}`}
                        className="inline-flex items-center gap-2 text-[14px] font-bold uppercase tracking-wider text-[#0B1F2A] hover:text-[#315B52] transition-colors group/link px-4 py-3"
                      >
                        <span className="border-b border-[#0B1F2A] group-hover/link:border-[#315B52]">Full Curriculum Vitae</span>
                        <ArrowRight size={15} className="text-[#B39A68] group-hover/link:translate-x-1.5 transition-transform" />
                      </Link>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

        </div>
      </section>

      {/* 3. Bottom CTA Banner */}
      <section className="bg-[#315B52] text-[#FCFBF8] py-20 sm:py-24">
        <div className="max-w-[1100px] mx-auto px-4 sm:px-6 lg:px-12 text-center">
          <h3 className="font-serif text-[38px] sm:text-[48px] lg:text-[56px] leading-[1.08] mb-6">
            Accepting New Adult Patients in Newark.
          </h3>
          <p className="font-sans text-[17px] sm:text-[19px] text-[#D9D0C5] max-w-xl mx-auto leading-[1.7] mb-10">
            Most appointments are accommodated within 48 to 72 hours. Same-day urgent consultations are also welcomed.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              to="/appointments"
              className="px-8 py-4 bg-[#FCFBF8] hover:bg-[#F4EFE6] text-[#0B1F2A] font-bold uppercase tracking-wider text-[14px] transition-colors"
            >
              Book Your Appointment
            </Link>
            <a
              href={`tel:${NEWARK_PRACTICE_INFO.rawPhone}`}
              className="px-7 py-4 border border-[#FCFBF8]/40 hover:border-[#FCFBF8] text-[#FCFBF8] font-semibold uppercase tracking-wider text-[14px] transition-colors"
            >
              Call (973) 412-9404
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
